import { storage } from "../utils/storage";
import { calculateQuotation } from "../utils/calculations";

// Keys used in localStorage
const KEYS = {
  QUOTATIONS: "qaems_quotations",
  SITE_VISITS: "qaems_site_visits",
  VENDORS: "qaems_vendors",
  SETTINGS: "qaems_settings",
  NOTIFICATIONS: "qaems_notifications",
  WORKFLOW: "qaems_workflow",
  CLIENTS: "qaems_clients",
  INVOICES: "qaems_invoices"
};

// Default System Settings
const DEFAULT_SETTINGS = {
  companyName: "Glory Simon Interiors",
  companyAddress: "102, Design Avenue, Suite A, New York, NY",
  companyEmail: "info@glorysimon.com",
  companyPhone: "+1 (555) 987-6543",
  gstPercentage: 18,
  defaultLabourCharges: 15,
  currency: "USD",
  currencySymbol: "$",
  emailNotifications: true,
  pushNotifications: true
};

// Seeding CRM Clients
const MOCK_CLIENTS = [
  {
    id: "CLI-001",
    name: "David Harrison",
    phone: "555-0199",
    email: "david.h@example.com",
    address: "742 Evergreen Terrace",
    location: "Brooklyn",
    stage: "Proposal",
    createdAt: "2026-05-15",
    timeline: [
      { date: "2026-05-15", title: "Enquiry Registered", desc: "Contacted us via website for Living Room redesign." },
      { date: "2026-06-02", title: "Site Audit Done", desc: "Site measurements completed by Sarah Jenkins." },
      { date: "2026-06-05", title: "Proposal Shared", desc: "Quotation Q-2026-001 sent to client." }
    ]
  },
  {
    id: "CLI-002",
    name: "Sonia Martinez",
    phone: "555-0144",
    email: "sonia.m@example.com",
    address: "89 Broadway St",
    location: "Manhattan",
    stage: "Proposal",
    createdAt: "2026-05-20",
    timeline: [
      { date: "2026-05-20", title: "Enquiry Registered", desc: "Office redesign enquiry." },
      { date: "2026-06-12", title: "Proposal Shared", desc: "Quotation Q-2026-002 sent to client." }
    ]
  },
  {
    id: "CLI-003",
    name: "Marcus Vance",
    phone: "555-0168",
    email: "marcus.v@example.com",
    address: "32 Oakridge Ln",
    location: "Queens",
    stage: "Signed",
    createdAt: "2026-05-10",
    timeline: [
      { date: "2026-05-10", title: "Enquiry Registered", desc: "Modular kitchen renovation." },
      { date: "2026-06-15", title: "Contract Signed", desc: "Approved Q-2026-003. Invoice issued." }
    ]
  },
  {
    id: "CLI-004",
    name: "Emily Watson",
    phone: "555-0122",
    email: "emily.w@example.com",
    address: "512 Pinecrest Road",
    location: "Staten Island",
    stage: "Lead",
    createdAt: "2026-06-01",
    timeline: [
      { date: "2026-06-01", title: "Enquiry Registered", desc: "Two bedrooms complete redesign." }
    ]
  },
  {
    id: "CLI-005",
    name: "Robert Downey",
    phone: "555-0185",
    email: "tony@starkcorp.com",
    address: "10880 Malibu Point",
    location: "Upstate NY",
    stage: "Audit",
    createdAt: "2026-06-10",
    timeline: [
      { date: "2026-06-10", title: "Enquiry Registered", desc: "Elite smart conference room." },
      { date: "2026-06-18", title: "Proposal Shared", desc: "Shared high budget draft Q-2026-005." }
    ]
  }
];

// Seeding Invoices
const MOCK_INVOICES = [
  {
    id: "INV-2026-001",
    quoteId: "Q-2026-001",
    clientName: "David Harrison",
    amount: 32450,
    status: "Pending",
    date: "2026-06-05",
    dueDate: "2026-07-05",
    notes: "50% Mobilization advance payment request for Living Room overhaul."
  },
  {
    id: "INV-2026-002",
    quoteId: "Q-2026-003",
    clientName: "Marcus Vance",
    amount: 19800,
    status: "Paid",
    date: "2026-06-15",
    dueDate: "2026-06-30",
    notes: "Full payment received for modular kitchen fabrication."
  },
  {
    id: "INV-2026-003",
    quoteId: "Q-2026-004",
    clientName: "Emily Watson",
    amount: 8500,
    status: "Overdue",
    date: "2026-06-01",
    dueDate: "2026-06-15",
    notes: "Consultation and site plan blueprint charges overdue."
  }
];

// Seed 9-Stage Kanban Board
const DEFAULT_KANBAN = {
  enquiry: [
    { id: "KB-1", title: "Emma Stone - Bedroom Makeover", budget: "$4,000", date: "June 18" },
    { id: "KB-2", title: "Zen Cafe - Commercial Redesign", budget: "$15,000", date: "June 17" }
  ],
  siteVisitScheduled: [
    { id: "KB-3", title: "David Harrison - Space Scanning", budget: "$12,500", date: "June 21" }
  ],
  siteVisitCompleted: [
    { id: "KB-4", title: "Sonia Martinez - Office Measurement", budget: "$28,000", date: "June 12" }
  ],
  designApproval: [
    { id: "KB-5", title: "Liam Neeson - Dining Cabinetry", budget: "$6,500", date: "June 12" }
  ],
  quotationGenerated: [
    { id: "KB-6", title: "Robert Downey - Conference Room", budget: "$82,000", date: "June 18" }
  ],
  quotationSent: [
    { id: "KB-10", title: "Scarlett Johansson - Home Study", budget: "$10,500", date: "June 19" }
  ],
  approved: [
    { id: "KB-7", title: "Marcus Vance - Quartz Kitchen", budget: "$16,200", date: "June 15" }
  ],
  execution: [
    { id: "KB-8", title: "Christian Bale - Penthouse Study", budget: "$25,000", date: "May 29" }
  ],
  completed: [
    { id: "KB-9", title: "Anne Hathaway - Cozy Nursery", budget: "$8,500", date: "May 15" }
  ]
};

// Initial Mock Quotations
const MOCK_QUOTATIONS_INPUTS = [
  {
    id: "Q-2026-001",
    clientName: "David Harrison",
    phone: "555-0199",
    email: "david.h@example.com",
    address: "742 Evergreen Terrace",
    projectType: "Residential",
    projectLocation: "Brooklyn",
    roomType: "Living Room",
    area: 450,
    numRooms: 1,
    scopeOfWork: "Complete redesign of living area including modular cabinetry, custom paint, false ceiling with cove lighting and brand new sectional seating arrangement.",
    materialQuality: "Premium",
    furnitureOptions: { wardrobe: false, modularKitchen: false, tvUnit: true, falseCeiling: true, studyTable: false, storageUnits: true },
    lightingType: "Smart",
    labourCost: 18,
    installationCharges: 1200,
    taxPercentage: 18,
    discountPercentage: 5,
    otherCharges: 500,
    status: "Approved",
    date: "2026-06-05",
    notes: "Client preferred warm tones and smart control integrations."
  },
  {
    id: "Q-2026-002",
    clientName: "Sonia Martinez",
    phone: "555-0144",
    email: "sonia.m@example.com",
    address: "89 Broadway St",
    projectType: "Commercial",
    projectLocation: "Manhattan",
    roomType: "Office",
    area: 1200,
    numRooms: 3,
    scopeOfWork: "Interior design of 3 executive cabins and reception lounge. Needs high durability materials and formal aesthetics.",
    materialQuality: "Standard",
    furnitureOptions: { wardrobe: false, modularKitchen: false, tvUnit: false, falseCeiling: true, studyTable: true, storageUnits: true },
    lightingType: "Decorative",
    labourCost: 15,
    installationCharges: 2500,
    taxPercentage: 18,
    discountPercentage: 10,
    otherCharges: 1000,
    status: "Pending",
    date: "2026-06-12",
    notes: "Requires acoustic paneling in rooms."
  },
  {
    id: "Q-2026-003",
    clientName: "Marcus Vance",
    phone: "555-0168",
    email: "marcus.v@example.com",
    address: "32 Oakridge Ln",
    projectType: "Residential",
    projectLocation: "Queens",
    roomType: "Kitchen",
    area: 280,
    numRooms: 1,
    scopeOfWork: "Modern modular kitchen with quartz countertop, soft-close drawers, integrated microwave cabinet, and spot task lighting.",
    materialQuality: "Premium",
    furnitureOptions: { wardrobe: false, modularKitchen: true, tvUnit: false, falseCeiling: false, studyTable: false, storageUnits: true },
    lightingType: "Basic",
    labourCost: 20,
    installationCharges: 1800,
    taxPercentage: 18,
    discountPercentage: 0,
    otherCharges: 200,
    status: "Approved",
    date: "2026-06-15",
    notes: "Requires premium wood finishes."
  },
  {
    id: "Q-2026-004",
    clientName: "Emily Watson",
    phone: "555-0122",
    email: "emily.w@example.com",
    address: "512 Pinecrest Road",
    projectType: "Residential",
    projectLocation: "Staten Island",
    roomType: "Bedroom",
    area: 320,
    numRooms: 2,
    scopeOfWork: "Two bedrooms complete furniture makeover. Includes 3-door wardrobe, study corner and custom wall moldings.",
    materialQuality: "Basic",
    furnitureOptions: { wardrobe: true, modularKitchen: false, tvUnit: true, falseCeiling: false, studyTable: true, storageUnits: false },
    lightingType: "Basic",
    labourCost: 12,
    installationCharges: 900,
    taxPercentage: 18,
    discountPercentage: 15,
    otherCharges: 0,
    status: "Rejected",
    date: "2026-06-01",
    notes: "Budget mismatch. Client requested basic level but still found total price high."
  },
  {
    id: "Q-2026-005",
    clientName: "Robert Downey",
    phone: "555-0185",
    email: "tony@starkcorp.com",
    address: "10880 Malibu Point",
    projectType: "Commercial",
    projectLocation: "Upstate NY",
    roomType: "Office",
    area: 3000,
    numRooms: 5,
    scopeOfWork: "High-tech smart conference room and engineering lounge. Custom glass panels, acoustic design, smart lighting.",
    materialQuality: "Premium",
    furnitureOptions: { wardrobe: false, modularKitchen: false, tvUnit: true, falseCeiling: true, studyTable: true, storageUnits: true },
    lightingType: "Smart",
    labourCost: 25,
    installationCharges: 15000,
    taxPercentage: 18,
    discountPercentage: 8,
    otherCharges: 5000,
    status: "Pending",
    date: "2026-06-18",
    notes: "Very high priority project. Needs elite grade materials."
  }
];

// Seed Site Visits
const MOCK_SITE_VISITS = [
  {
    id: "SV-001",
    clientName: "David Harrison",
    phone: "555-0199",
    date: "2026-06-21",
    time: "10:30 AM",
    location: "742 Evergreen Terrace, Brooklyn",
    designer: "Sarah Jenkins",
    status: "Scheduled",
    notes: "Material catalog walk-through and final space scanning."
  },
  {
    id: "SV-002",
    clientName: "Sonia Martinez",
    phone: "555-0144",
    date: "2026-06-23",
    time: "02:00 PM",
    location: "89 Broadway St, Manhattan",
    designer: "Alex Rivera",
    status: "Scheduled",
    notes: "Site measurement and initial floor plan alignment."
  },
  {
    id: "SV-003",
    clientName: "John Smith",
    phone: "555-0213",
    date: "2026-06-14",
    time: "04:30 PM",
    location: "14 Elm St, Queens",
    designer: "Sarah Jenkins",
    status: "Completed",
    notes: "Initial consultation done. Quotation request generated."
  },
  {
    id: "SV-004",
    clientName: "Robert Downey",
    phone: "555-0185",
    date: "2026-06-25",
    time: "11:00 AM",
    location: "10880 Malibu Point, Upstate NY",
    designer: "Glory Simon",
    status: "Scheduled",
    notes: "Elite client site inspection."
  }
];

// Seed Vendors
const MOCK_VENDORS = [
  {
    id: "VND-001",
    name: "Apex Woodworks",
    specialty: "Modular Kitchen & Wardrobe Fabrication",
    phone: "555-0901",
    email: "orders@apexwood.com",
    rating: 4.8,
    activeProjects: 3,
    status: "Active"
  },
  {
    id: "VND-002",
    name: "Luxor Lighting Systems",
    specialty: "Smart & Decorative Lights Provider",
    phone: "555-0902",
    email: "b2b@luxor.com",
    rating: 4.5,
    activeProjects: 2,
    status: "Active"
  },
  {
    id: "VND-003",
    name: "Vogue Fabrics & Wall Coverings",
    specialty: "Upholstery, Curtains & Premium Wallpapers",
    phone: "555-0903",
    email: "design@voguefabrics.com",
    rating: 4.2,
    activeProjects: 1,
    status: "Active"
  },
  {
    id: "VND-004",
    name: "Stonex Marble & Granite",
    specialty: "Premium Countertops & Tile Supply",
    phone: "555-0904",
    email: "sales@stonex.com",
    rating: 4.9,
    activeProjects: 4,
    status: "Active"
  },
  {
    id: "VND-005",
    name: "EcoPaint Co.",
    specialty: "Non-toxic & Custom Textured Paints",
    phone: "555-0905",
    email: "contractors@ecopaint.com",
    rating: 4.0,
    activeProjects: 0,
    status: "Inactive"
  }
];

// Seed Notifications
const MOCK_NOTIFICATIONS = [
  {
    id: "NTF-001",
    type: "approval",
    title: "Quotation Q-2026-001 Approved",
    message: "Client David Harrison has approved the quotation for their Living Room redesign.",
    time: "2 hours ago",
    read: false
  },
  {
    id: "NTF-002",
    type: "visit",
    title: "New Site Visit Scheduled",
    message: "A site visit for Robert Downey is scheduled on June 25th at 11:00 AM.",
    time: "5 hours ago",
    read: false
  },
  {
    id: "NTF-003",
    type: "system",
    title: "System Update",
    message: "QAEMS has been updated to version 2.5. Support for invoice generation and multi-user roles is live.",
    time: "1 day ago",
    read: true
  },
  {
    id: "NTF-004",
    type: "rejection",
    title: "Quotation Q-2026-004 Rejected",
    message: "Client Emily Watson rejected the Bedroom quotation due to pricing concerns.",
    time: "3 days ago",
    read: true
  }
];

export const initializeDatabase = () => {
  // 1. Settings
  if (!storage.get(KEYS.SETTINGS)) {
    storage.set(KEYS.SETTINGS, DEFAULT_SETTINGS);
  }

  const currentSettings = storage.get(KEYS.SETTINGS) || DEFAULT_SETTINGS;

  // 2. Clients (CRM)
  if (!storage.get(KEYS.CLIENTS)) {
    storage.set(KEYS.CLIENTS, MOCK_CLIENTS);
  }

  // 3. Invoices
  if (!storage.get(KEYS.INVOICES)) {
    storage.set(KEYS.INVOICES, MOCK_INVOICES);
  }

  // 4. Quotations
  if (!storage.get(KEYS.QUOTATIONS)) {
    const seededQuotes = MOCK_QUOTATIONS_INPUTS.map((quote) => {
      const breakdown = calculateQuotation(quote, currentSettings);
      return {
        ...quote,
        costBreakdown: breakdown
      };
    });
    storage.set(KEYS.QUOTATIONS, seededQuotes);
  }

  // 5. Site Visits
  if (!storage.get(KEYS.SITE_VISITS)) {
    storage.set(KEYS.SITE_VISITS, MOCK_SITE_VISITS);
  }

  // 6. Vendors
  if (!storage.get(KEYS.VENDORS)) {
    storage.set(KEYS.VENDORS, MOCK_VENDORS);
  }

  // 7. Notifications
  if (!storage.get(KEYS.NOTIFICATIONS)) {
    storage.set(KEYS.NOTIFICATIONS, MOCK_NOTIFICATIONS);
  }

  // 8. Kanban Workflow
  if (!storage.get(KEYS.WORKFLOW)) {
    storage.set(KEYS.WORKFLOW, DEFAULT_KANBAN);
  }
};

// Run initialization immediately
initializeDatabase();

// Service APIs
export const quotationService = {
  // SETTINGS
  getSettings: () => {
    return storage.get(KEYS.SETTINGS) || DEFAULT_SETTINGS;
  },
  saveSettings: (settings) => {
    storage.set(KEYS.SETTINGS, settings);
    // Recalculate all quotations
    const quotes = storage.get(KEYS.QUOTATIONS) || [];
    const updatedQuotes = quotes.map((q) => {
      const breakdown = calculateQuotation(q, settings);
      return { ...q, costBreakdown: breakdown };
    });
    storage.set(KEYS.QUOTATIONS, updatedQuotes);
    return settings;
  },

  // CLIENTS (CRM)
  getClients: () => {
    return storage.get(KEYS.CLIENTS) || [];
  },
  createClient: (clientData) => {
    const clients = quotationService.getClients();
    const id = `CLI-${String(clients.length + 1).padStart(3, "0")}`;
    const newClient = {
      ...clientData,
      id,
      stage: clientData.stage || "Lead",
      createdAt: new Date().toISOString().split("T")[0],
      timeline: [
        { date: new Date().toISOString().split("T")[0], title: "Account Created", desc: `Client profile initialized in CRM.` }
      ]
    };
    clients.push(newClient);
    storage.set(KEYS.CLIENTS, clients);
    return newClient;
  },
  updateClient: (id, updatedData) => {
    const clients = quotationService.getClients();
    const index = clients.findIndex((c) => c.id === id);
    if (index === -1) return null;
    
    // Add timeline log if stage changed
    const timeline = [...(clients[index].timeline || [])];
    if (clients[index].stage !== updatedData.stage) {
      timeline.unshift({
        date: new Date().toISOString().split("T")[0],
        title: "Stage Mutation",
        desc: `Client state shifted from ${clients[index].stage} to ${updatedData.stage}.`
      });
    }

    const updatedClient = {
      ...clients[index],
      ...updatedData,
      timeline
    };
    clients[index] = updatedClient;
    storage.set(KEYS.CLIENTS, clients);
    return updatedClient;
  },
  deleteClient: (id) => {
    const clients = quotationService.getClients();
    const filtered = clients.filter((c) => c.id !== id);
    storage.set(KEYS.CLIENTS, filtered);
    return true;
  },

  // INVOICES
  getInvoices: () => {
    return storage.get(KEYS.INVOICES) || [];
  },
  createInvoice: (invoiceData) => {
    const invoices = quotationService.getInvoices();
    const id = `INV-${new Date().getFullYear()}-${String(invoices.length + 1).padStart(3, "0")}`;
    const newInvoice = {
      ...invoiceData,
      id,
      date: new Date().toISOString().split("T")[0],
      status: invoiceData.status || "Pending"
    };
    invoices.push(newInvoice);
    storage.set(KEYS.INVOICES, invoices);

    // Trigger Notification
    quotationService.addNotification({
      type: "system",
      title: "Invoice Issued",
      message: `Invoice ${id} for amount ${quotationService.getSettings().currencySymbol}${Number(invoiceData.amount).toLocaleString()} issued to ${invoiceData.clientName}.`
    });

    return newInvoice;
  },
  updateInvoiceStatus: (id, status) => {
    const invoices = quotationService.getInvoices();
    const index = invoices.findIndex((i) => i.id === id);
    if (index === -1) return null;
    invoices[index].status = status;
    storage.set(KEYS.INVOICES, invoices);
    return invoices[index];
  },

  // QUOTATIONS
  getQuotations: () => {
    return storage.get(KEYS.QUOTATIONS) || [];
  },
  getQuotationById: (id) => {
    const quotes = storage.get(KEYS.QUOTATIONS) || [];
    return quotes.find((q) => q.id === id) || null;
  },
  createQuotation: (inputData) => {
    const quotes = storage.get(KEYS.QUOTATIONS) || [];
    const settings = quotationService.getSettings();
    
    const year = new Date().getFullYear();
    const nextNum = String(quotes.length + 1).padStart(3, "0");
    const id = `Q-${year}-${nextNum}`;

    const costBreakdown = calculateQuotation(inputData, settings);

    const newQuotation = {
      ...inputData,
      id,
      date: new Date().toISOString().split("T")[0],
      costBreakdown
    };

    quotes.push(newQuotation);
    storage.set(KEYS.QUOTATIONS, quotes);

    // Add invoice automatically if status is Approved
    if (inputData.status === "Approved") {
      quotationService.createInvoice({
        quoteId: id,
        clientName: inputData.clientName,
        amount: costBreakdown.grandTotal,
        dueDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split("T")[0],
        notes: `Auto-generated advance request for quotation ${id}.`
      });
    }

    // Add notification
    quotationService.addNotification({
      type: "system",
      title: "New Quotation Generated",
      message: `Quotation ${id} has been created for client ${inputData.clientName}.`
    });

    // Add to Kanban
    const kanban = quotationService.getWorkflow();
    kanban.quotationGenerated.push({
      id: `KB-Q-${id}`,
      title: `${inputData.clientName} - ${inputData.roomType}`,
      budget: `${settings.currencySymbol}${costBreakdown.grandTotal.toLocaleString()}`,
      date: "Today"
    });
    quotationService.saveWorkflow(kanban);

    // Sync CRM client timeline if client exists
    const clients = quotationService.getClients();
    const client = clients.find((c) => c.name.toLowerCase() === inputData.clientName.toLowerCase());
    if (client) {
      const timeline = [...(client.timeline || [])];
      timeline.unshift({
        date: new Date().toISOString().split("T")[0],
        title: "Proposal Shared",
        desc: `Shared quotation ${id} with total budget of ${settings.currencySymbol}${costBreakdown.grandTotal.toLocaleString()}.`
      });
      quotationService.updateClient(client.id, { ...client, stage: "Proposal", timeline });
    }

    return newQuotation;
  },
  updateQuotation: (id, updatedData) => {
    const quotes = storage.get(KEYS.QUOTATIONS) || [];
    const index = quotes.findIndex((q) => q.id === id);
    if (index === -1) return null;

    const settings = quotationService.getSettings();
    const costBreakdown = calculateQuotation(updatedData, settings);

    const prevStatus = quotes[index].status;
    const updatedQuotation = {
      ...quotes[index],
      ...updatedData,
      costBreakdown
    };

    quotes[index] = updatedQuotation;
    storage.set(KEYS.QUOTATIONS, quotes);

    // If quotation approved, create invoice automatically
    if (prevStatus !== "Approved" && updatedData.status === "Approved") {
      quotationService.createInvoice({
        quoteId: id,
        clientName: updatedData.clientName,
        amount: costBreakdown.grandTotal,
        dueDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split("T")[0],
        notes: `Advance request invoice for approved quotation ${id}.`
      });

      // Update CRM stage
      const clients = quotationService.getClients();
      const client = clients.find((c) => c.name.toLowerCase() === updatedData.clientName.toLowerCase());
      if (client) {
        const timeline = [...(client.timeline || [])];
        timeline.unshift({
          date: new Date().toISOString().split("T")[0],
          title: "Contract Approved",
          desc: `Client approved quote ${id}. Advance invoice issued.`
        });
        quotationService.updateClient(client.id, { ...client, stage: "Signed", timeline });
      }
    }

    // Add notification if status changed
    if (prevStatus !== updatedData.status) {
      quotationService.addNotification({
        type: updatedData.status.toLowerCase() === "approved" ? "approval" : "system",
        title: `Quotation ${id} Status: ${updatedData.status}`,
        message: `Quotation status for ${updatedData.clientName} was updated to ${updatedData.status}.`
      });
    }

    return updatedQuotation;
  },
  deleteQuotation: (id) => {
    const quotes = storage.get(KEYS.QUOTATIONS) || [];
    const filteredQuotes = quotes.filter((q) => q.id !== id);
    storage.set(KEYS.QUOTATIONS, filteredQuotes);
    return true;
  },

  // SITE VISITS
  getSiteVisits: () => {
    return storage.get(KEYS.SITE_VISITS) || [];
  },
  createSiteVisit: (visitData) => {
    const visits = storage.get(KEYS.SITE_VISITS) || [];
    const id = `SV-${String(visits.length + 1).padStart(3, "0")}`;
    const newVisit = {
      ...visitData,
      id,
      status: "Scheduled"
    };
    visits.push(newVisit);
    storage.set(KEYS.SITE_VISITS, visits);

    // Trigger Notification
    quotationService.addNotification({
      type: "visit",
      title: "Site Visit Scheduled",
      message: `A new site visit has been scheduled for ${visitData.clientName} on ${visitData.date} at ${visitData.time}.`
    });

    // Add to Kanban Site Visit stage
    const kanban = quotationService.getWorkflow();
    kanban.siteVisitScheduled.push({
      id: `KB-SV-${id}`,
      title: `${visitData.clientName} - Consultation`,
      budget: "TBD",
      date: visitData.date
    });
    quotationService.saveWorkflow(kanban);

    // Update CRM timeline
    const clients = quotationService.getClients();
    const client = clients.find((c) => c.name.toLowerCase() === visitData.clientName.toLowerCase());
    if (client) {
      const timeline = [...(client.timeline || [])];
      timeline.unshift({
        date: visitData.date,
        title: "Site Visit Booked",
        desc: `Site visit scheduled at ${visitData.time} with designer ${visitData.designer}.`
      });
      quotationService.updateClient(client.id, { ...client, stage: "Audit", timeline });
    }

    return newVisit;
  },
  updateSiteVisitStatus: (id, status) => {
    const visits = storage.get(KEYS.SITE_VISITS) || [];
    const index = visits.findIndex((v) => v.id === id);
    if (index === -1) return null;
    visits[index].status = status;
    storage.set(KEYS.SITE_VISITS, visits);

    if (status === "Completed") {
      const clients = quotationService.getClients();
      const client = clients.find((c) => c.name.toLowerCase() === visits[index].clientName.toLowerCase());
      if (client) {
        const timeline = [...(client.timeline || [])];
        timeline.unshift({
          date: new Date().toISOString().split("T")[0],
          title: "Site Visit Audited",
          desc: `Measurements finalized. Scope definition draft unlocked.`
        });
        quotationService.updateClient(client.id, { ...client, stage: "Audit", timeline });
      }
    }

    return visits[index];
  },

  // VENDORS
  getVendors: () => {
    return storage.get(KEYS.VENDORS) || [];
  },

  // NOTIFICATIONS
  getNotifications: () => {
    return storage.get(KEYS.NOTIFICATIONS) || [];
  },
  addNotification: ({ type, title, message }) => {
    const list = storage.get(KEYS.NOTIFICATIONS) || [];
    const newNtf = {
      id: `NTF-${Date.now()}`,
      type,
      title,
      message,
      time: "Just now",
      read: false
    };
    list.unshift(newNtf);
    storage.set(KEYS.NOTIFICATIONS, list);
    return newNtf;
  },
  markAllNotificationsRead: () => {
    const list = storage.get(KEYS.NOTIFICATIONS) || [];
    const updated = list.map((n) => ({ ...n, read: true }));
    storage.set(KEYS.NOTIFICATIONS, updated);
    return updated;
  },

  // KANBAN WORKFLOW
  getWorkflow: () => {
    return storage.get(KEYS.WORKFLOW) || DEFAULT_KANBAN;
  },
  saveWorkflow: (workflowData) => {
    storage.set(KEYS.WORKFLOW, workflowData);
    return workflowData;
  },

  // ANALYTICS & DASHBOARD
  getAnalytics: () => {
    const quotes = quotationService.getQuotations();
    const visits = quotationService.getSiteVisits();
    const clients = quotationService.getClients();
    const invoices = quotationService.getInvoices();
    
    // Status counts
    let total = quotes.length;
    let approved = 0;
    let pending = 0;
    let rejected = 0;
    let totalRevenue = 0;

    quotes.forEach((q) => {
      if (q.status === "Approved") {
        approved++;
        totalRevenue += q.costBreakdown.grandTotal;
      } else if (q.status === "Pending" || q.status === "Under Review" || q.status === "Draft") {
        pending++;
      } else if (q.status === "Rejected") {
        rejected++;
      }
    });

    const activeProjects = approved;
    const upcomingVisits = visits.filter((v) => v.status === "Scheduled").length;
    const totalClients = clients.length;

    // Pending payments count
    const pendingPayments = invoices
      .filter((i) => i.status === "Pending" || i.status === "Overdue")
      .reduce((acc, curr) => acc + (Number(curr.amount) || 0), 0);

    return {
      totalQuotations: total,
      approvedQuotations: approved,
      pendingQuotations: pending,
      rejectedQuotations: rejected,
      totalRevenue,
      activeProjects,
      upcomingSiteVisits: upcomingVisits,
      totalClients,
      pendingPayments
    };
  }
};
