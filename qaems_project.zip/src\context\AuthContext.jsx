import React, { createContext, useContext, useState } from "react";

const AuthContext = createContext();

const usersDB = [
  {
    email: "admin@glorysimon.com",
    password: "admin123",
    role: "Admin",
    name: "Admin User"
  },
  {
    email: "designer@glorysimon.com",
    password: "designer123",
    role: "Interior Designer",
    name: "Design Lead"
  }
];

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(
    JSON.parse(localStorage.getItem("qaems_user")) || null
  );

  const login = (email, password) => {
    const found = usersDB.find(
      (u) => u.email === email && u.password === password
    );

    if (!found) return false;

    setUser(found);
    localStorage.setItem("qaems_user", JSON.stringify(found));
    return true;
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem("qaems_user");
  };

  return (
    <AuthContext.Provider value={{ user, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);