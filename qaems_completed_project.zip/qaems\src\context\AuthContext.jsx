import React, { createContext, useContext, useState } from "react";

const AuthContext = createContext();

const usersDB = [
  {
    email: "admin@glorysimon.com",
    password: "admin123",
    role: "Admin",
    name: "Admin User"
  },
  {
    email: "designer@glorysimon.com",
    password: "designer123",
    role: "Interior Designer",
    name: "Design Lead"
  }
];

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(
    JSON.parse(localStorage.getItem("qaems_user")) || null
  );

  const login = async (email, password) => {
    try {
      const response = await fetch("http://localhost:5000/api/v1/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password })
      });
      const data = await response.json();
      if (data.success && data.data) {
        setUser(data.data.user);
        localStorage.setItem("qaems_user", JSON.stringify(data.data.user));
        localStorage.setItem("qaems_token", data.data.token);
        return true;
      }
      return false;
    } catch (error) {
      console.error("Login failed:", error);
      return false;
    }
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem("qaems_user");
    localStorage.removeItem("qaems_token");
  };

  return (
    <AuthContext.Provider value={{ user, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);